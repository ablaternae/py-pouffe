#!/usr/bin/env python
#-*- coding:utf-8 -*-

"""Simple RBAC

This is a simple role based access control utility in Python.
"""

__all__ = ["acl", "context", "proxy"]
